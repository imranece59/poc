import streamlit as st
from agent.redshift_agent import build_and_run_query

st.title("Redshift AI SQL Agent")
prompt = st.text_input("Ask a question about your data:")

if prompt:
    with st.spinner("Thinking..."):
        answer = build_and_run_query(prompt)
        st.success("Answer:")
        st.write(answer)
