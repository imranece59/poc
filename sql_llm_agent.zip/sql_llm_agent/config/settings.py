import os

AWS_REGION = "us-east-1"
BEDROCK_LLM_MODEL = "anthropic.claude-v2"

REDSHIFT_CONN = {
    "host": "your-redshift-host",
    "port": 5439,
    "user": "your-user",
    "password": "your-password",
    "dbname": "your-db"
}
