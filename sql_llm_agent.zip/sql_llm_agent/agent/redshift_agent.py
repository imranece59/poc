import psycopg2
import json
from config.settings import REDSHIFT_CONN
from agent.bedrock_llm import generate_sql_from_llm, generate_final_answer

def get_metadata():
    conn = psycopg2.connect(**REDSHIFT_CONN)
    cur = conn.cursor()

    cur.execute("SELECT table_schema, table_name, table_description FROM table_description;")
    tables = cur.fetchall()

    cur.execute("SELECT table_schema, table_name, column_name, description FROM col_description;")
    columns = cur.fetchall()

    cur.close()
    conn.close()

    table_lines = [f"{s}.{t}: {d}" for s, t, d in tables]
    column_lines = [f"{s}.{t}.{c} ({desc})" for s, t, c, desc in columns]

    return "\\n".join(table_lines + column_lines)

def build_and_run_query(prompt: str):
    metadata = get_metadata()
    sql = generate_sql_from_llm(prompt, metadata)

    if sql.startswith("ERROR"):
        return sql

    try:
        conn = psycopg2.connect(**REDSHIFT_CONN)
        cur = conn.cursor()
        cur.execute(sql)
        rows = cur.fetchall()
        columns = [desc[0] for desc in cur.description]
        cur.close()
        conn.close()

        results = [dict(zip(columns, row)) for row in rows]
        return generate_final_answer(prompt, results)

    except Exception as e:
        return f"Query failed: {str(e)}"
