import boto3
import json
from config.settings import AWS_REGION, BEDROCK_LLM_MODEL

bedrock = boto3.client("bedrock-runtime", region_name=AWS_REGION)

def generate_sql_from_llm(prompt: str, metadata: str):
    final_prompt = f"""
You are a SQL expert. Based on the metadata below and the user query, generate the correct SQL to run.

Metadata:
{metadata}

User Query:
"{prompt}"

Return only the SQL in this format:
<sql>
SELECT ...
</sql>
"""
    response = bedrock.invoke_model(
        modelId=BEDROCK_LLM_MODEL,
        body=json.dumps({ "prompt": final_prompt, "max_tokens": 500 }),
        contentType="application/json"
    )
    result = json.loads(response["body"].read())["completion"]
    start = result.find("<sql>")
    end = result.find("</sql>")
    if start != -1 and end != -1:
        return result[start+5:end].strip()
    return "ERROR: SQL not found in model response"

def generate_final_answer(user_prompt: str, result_rows: list):
    rows_text = json.dumps(result_rows, indent=2)
    final_prompt = f"""
You are a helpful data analyst. Given the user's question and the SQL query results, summarize the answer in plain English.

User question:
{user_prompt}

SQL results:
{rows_text}

Give a clear, concise answer to the user.
"""
    response = bedrock.invoke_model(
        modelId=BEDROCK_LLM_MODEL,
        body=json.dumps({ "prompt": final_prompt, "max_tokens": 300 }),
        contentType="application/json"
    )
    return json.loads(response["body"].read())["completion"]
