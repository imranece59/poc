import os

AWS_REGION = "us-east-1"
BEDROCK_EMBED_MODEL = "amazon.titan-embed-text-v1"
BEDROCK_LLM_MODEL = "anthropic.claude-v2"

REDSHIFT_CONN = {
    "host": "your-redshift-host",
    "port": "5439",
    "user": "your-user",
    "password": "your-password",
    "database": "your-db"
}

RDS_CONN = {
    "host": "your-rds-host",
    "user": "your-user",
    "password": "your-password",
    "dbname": "your-db"
}

CONFLUENCE_BASE_URL = "https://your-domain.atlassian.net/wiki"
CONFLUENCE_API_TOKEN = os.getenv("CONFLUENCE_API_TOKEN")
CONFLUENCE_USER = os.getenv("CONFLUENCE_USER")
