import requests
from config.settings import CONFLUENCE_BASE_URL, CONFLUENCE_USER, CONFLUENCE_API_TOKEN

def fetch_page_content(query: str):
    search_url = f"{CONFLUENCE_BASE_URL}/rest/api/content/search?cql=title~\"{query}\""
    auth = (CONFLUENCE_USER, CONFLUENCE_API_TOKEN)
    response = requests.get(search_url, auth=auth)
    response.raise_for_status()
    results = response.json().get("results")
    if not results:
        return "No relevant Confluence pages found."
    page_id = results[0]["id"]

    content_url = f"{CONFLUENCE_BASE_URL}/rest/api/content/{page_id}?expand=body.storage"
    page = requests.get(content_url, auth=auth)
    page.raise_for_status()
    return page.json()["body"]["storage"]["value"]
