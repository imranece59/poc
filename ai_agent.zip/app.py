import streamlit as st
from agent.prompt_router import classify_prompt
from agent.redshift_agent import run_redshift_query
from agent.confluence_agent import run_confluence_query

st.title("Fixed Income AI Assistant")
prompt = st.text_input("Ask a question:")

if prompt:
    source = classify_prompt(prompt)
    with st.spinner(f"Querying {source}..."):
        if source == "redshift":
            answer = run_redshift_query(prompt)
        else:
            answer = run_confluence_query(prompt)
        st.success("Answer:")
        st.write(answer)
