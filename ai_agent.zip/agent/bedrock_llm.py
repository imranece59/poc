import boto3
import json
from config.settings import BEDROCK_EMBED_MODEL, BEDROCK_LLM_MODEL, AWS_REGION

bedrock = boto3.client("bedrock-runtime", region_name=AWS_REGION)

def get_embedding(text: str):
    response = bedrock.invoke_model(
        modelId=BEDROCK_EMBED_MODEL,
        body=json.dumps({"inputText": text}),
        contentType="application/json"
    )
    embedding = json.loads(response["body"].read())["embedding"]
    return embedding

def generate_answer(prompt: str, context_docs: list):
    context_text = "\n".join([doc["content"] for doc in context_docs])
    final_prompt = f"Use the following context to answer:\n{context_text}\n\nQuestion: {prompt}"
    response = bedrock.invoke_model(
        modelId=BEDROCK_LLM_MODEL,
        body=json.dumps({"prompt": final_prompt, "max_tokens": 500}),
        contentType="application/json"
    )
    return json.loads(response["body"].read())["completion"]
