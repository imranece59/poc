from db.rds_connector import store_embedding, query_similar_embeddings
from agent.bedrock_llm import get_embedding, generate_answer
import psycopg2
from config.settings import REDSHIFT_CONN

def run_redshift_query(prompt: str):
    # basic SQL generation for demo - in real case this should be dynamic
    sql = "SELECT * FROM bval ORDER BY updated_at DESC LIMIT 1;"
    conn = psycopg2.connect(**REDSHIFT_CONN)
    cur = conn.cursor()
    cur.execute(sql)
    rows = cur.fetchall()
    result = str(rows)
    cur.close()
    conn.close()

    emb = get_embedding(result)
    store_embedding("redshift", "bval_result", result, emb)
    retrieved_docs = query_similar_embeddings(emb)

    return generate_answer(prompt, retrieved_docs)
