from utils.confluence_client import fetch_page_content
from db.rds_connector import store_embedding, query_similar_embeddings
from agent.bedrock_llm import get_embedding, generate_answer

def run_confluence_query(prompt: str):
    content = fetch_page_content(prompt)  # find and return matching content
    emb = get_embedding(content)
    store_embedding("confluence", "project_page", content, emb)
    relevant = query_similar_embeddings(emb)
    return generate_answer(prompt, relevant)
