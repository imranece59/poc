def classify_prompt(prompt: str) -> str:
    if any(word in prompt.lower() for word in ["rate", "spread", "bval"]):
        return "redshift"
    return "confluence"
