import psycopg2
import uuid
from config.settings import RDS_CONN

def store_embedding(source_type, source_id, content, embedding):
    conn = psycopg2.connect(**RDS_CONN)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO embeddings (id, source_type, source_id, content, embedding) VALUES (%s, %s, %s, %s, %s)",
        (str(uuid.uuid4()), source_type, source_id, content, embedding)
    )
    conn.commit()
    cur.close()
    conn.close()

def query_similar_embeddings(embedding, top_k=3):
    conn = psycopg2.connect(**RDS_CONN)
    cur = conn.cursor()
    cur.execute(
        "SELECT content FROM embeddings ORDER BY embedding <-> %s LIMIT %s;",
        (embedding, top_k)
    )
    results = [{"content": row[0]} for row in cur.fetchall()]
    cur.close()
    conn.close()
    return results
