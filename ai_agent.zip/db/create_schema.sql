CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE embeddings (
    id UUID PRIMARY KEY,
    source_type TEXT,
    source_id TEXT,
    content TEXT,
    embedding VECTOR(1536),
    created_at TIMESTAMP DEFAULT now()
);
